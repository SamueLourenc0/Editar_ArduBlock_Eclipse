package com.ardublock.ui;

public class ArduBlockToolFrame extends OpenblocksFrame {
	private static final long serialVersionUID = 2841155965906223806L;
}
