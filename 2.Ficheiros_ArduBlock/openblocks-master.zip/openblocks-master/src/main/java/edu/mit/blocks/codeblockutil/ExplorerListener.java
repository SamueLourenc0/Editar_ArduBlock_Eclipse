package edu.mit.blocks.codeblockutil;

public interface ExplorerListener {

    public void explorerEventOccurred(ExplorerEvent event);
}
