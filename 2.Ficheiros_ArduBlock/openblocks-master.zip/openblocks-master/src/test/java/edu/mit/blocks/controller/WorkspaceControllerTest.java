package edu.mit.blocks.controller;

import static org.junit.Assert.*;

import org.junit.Test;

public class WorkspaceControllerTest {
	@Test
	public void testLoadProjectFromPath() {
        final WorkspaceController wc = new WorkspaceController();
//        wc.resetLanguage();
//        wc.setLangDefFilePath("support/ardublock_def.xml");
//        wc.loadFreshWorkspace();
//        wc.loadProjectFromPath("src/test/resources/ardublock001.xml");
	}
	
	@Test
	public void testLoadLandDefFromJar() {
        final WorkspaceController wc = new WorkspaceController();
//        wc.resetLanguage();
//        wc.setLangDefDtd(this.getClass().getResourceAsStream("/edu/mit/blocks/lang_def.dtd"));
//        wc.setLangDefStream(this.getClass().getResourceAsStream("/edu/mit/blocks/lang_def.xml"));
//        wc.loadFreshWorkspace();
//        wc.loadProjectFromPath("src/test/resources/test001.xml");
	}
}
